package com.cts.agrichain.subsidy.feign;

import com.cts.agrichain.subsidy.dto.FarmerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// ✅ fallback = FarmerClientFallback.class — runs when FARMER-SERVICE is down
// ✅ Load Balancer automatically picks the right FARMER-SERVICE instance from Eureka
@FeignClient(name = "FARMER-SERVICE", fallback = FarmerClientFallback.class)
public interface FarmerClient {

    @GetMapping("/farmers/{id}")
    FarmerDTO getFarmerById(@PathVariable("id") Integer id);
}