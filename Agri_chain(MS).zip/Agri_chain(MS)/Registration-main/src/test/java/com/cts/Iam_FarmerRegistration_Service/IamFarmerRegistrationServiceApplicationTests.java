package com.cts.Iam_FarmerRegistration_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IamFarmerRegistrationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
