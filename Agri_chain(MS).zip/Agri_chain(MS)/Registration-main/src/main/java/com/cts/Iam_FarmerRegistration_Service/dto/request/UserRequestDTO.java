package com.cts.Iam_FarmerRegistration_Service.dto.request;

import com.cts.Iam_FarmerRegistration_Service.enums.UserRole;
import com.cts.Iam_FarmerRegistration_Service.enums.UserStatus;
import lombok.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder // Added Builder for easier object creation in tests
public class UserRequestDTO {
    private String name;
    private String email;
    private String password;
    private String phone;
    private UserRole role;
    private UserStatus status;

    // --- Added Farmer Specific Fields ---
    private LocalDate dob;
    private String gender;
    private String address;
    private String landDetails;
}