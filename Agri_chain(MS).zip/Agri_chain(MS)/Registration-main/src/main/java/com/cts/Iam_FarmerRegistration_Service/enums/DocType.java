package com.cts.Iam_FarmerRegistration_Service.enums;

public enum DocType {
    ID_PROOF,
    LAND_RECORD,
    BANK_PASSBOOK,
    PROFILE_IMAGE
}
