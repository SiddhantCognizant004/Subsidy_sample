package com.cts.Iam_FarmerRegistration_Service.entity;

import com.cts.Iam_FarmerRegistration_Service.enums.FarmerStatus;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "farmer")
public class Farmer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long farmerId;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false) // Matches the foreign key in DB
    private Users users;

    private String name;
    private LocalDate dob;
    private String email;
    private String contactInfo;
    private String gender;
    private String address;
    private String landDetails;

    @Enumerated(EnumType.STRING)
    private FarmerStatus status;

    @OneToMany(mappedBy = "farmer", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<FarmerDocument> documents = new ArrayList<>(); // Initialize to avoid NullPointerException

    public void addDocument(FarmerDocument document) {
        documents.add(document);
        document.setFarmer(this);
    }

    public void removeDocument(FarmerDocument document) {
        documents.remove(document);
        document.setFarmer(null);
    }
}