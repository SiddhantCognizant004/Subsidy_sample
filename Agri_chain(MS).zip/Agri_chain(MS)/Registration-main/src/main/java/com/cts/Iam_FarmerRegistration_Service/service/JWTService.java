package com.cts.Iam_FarmerRegistration_Service.service;

import io.jsonwebtoken.Claims;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Map;
import java.util.function.Function;

public interface JWTService {
    String extractUserName(String token);
    <T> T extractClaim(String token, Function<Claims, T> claimsResolver);
    String generateToken(String username);
    String generateToken(Map<String, Object> extraClaims, String username);
    boolean validateToken(String token, UserDetails userDetails);
}