package com.cts.Iam_FarmerRegistration_Service.enums;

public enum UserRole {
    FARMER,
    TRADER,
    OFFICER,
    MANAGER,
    ADMIN,
    COMPLIANCE,
    AUDITOR
}