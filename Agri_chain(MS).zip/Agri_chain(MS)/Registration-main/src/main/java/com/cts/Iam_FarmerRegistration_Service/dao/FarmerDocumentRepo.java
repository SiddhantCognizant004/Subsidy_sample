package com.cts.Iam_FarmerRegistration_Service.dao;

import com.cts.Iam_FarmerRegistration_Service.entity.Farmer;
import com.cts.Iam_FarmerRegistration_Service.entity.FarmerDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FarmerDocumentRepo extends JpaRepository<FarmerDocument, Long> {

    List<FarmerDocument> findByFarmer(Farmer farmer);

    List<FarmerDocument> findByFarmer_FarmerId(Long farmerId);
}
