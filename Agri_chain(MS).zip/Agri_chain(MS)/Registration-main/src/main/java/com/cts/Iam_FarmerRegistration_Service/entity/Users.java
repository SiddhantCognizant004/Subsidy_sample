package com.cts.Iam_FarmerRegistration_Service.entity;

import com.cts.Iam_FarmerRegistration_Service.enums.UserRole;
import com.cts.Iam_FarmerRegistration_Service.enums.UserStatus;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    private String name;

    @Enumerated(EnumType.STRING)
    private UserRole role;

    @Column(length = 10)
    private String phone;

    @Enumerated(EnumType.STRING)
    private UserStatus status;
}