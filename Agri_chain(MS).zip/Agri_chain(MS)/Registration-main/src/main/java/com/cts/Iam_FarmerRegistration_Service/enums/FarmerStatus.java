package com.cts.Iam_FarmerRegistration_Service.enums;

public enum FarmerStatus {
    ACTIVE,
    PENDING_VERIFICATION,
    APPROVED,
    REJECTED,
    INACTIVE
}