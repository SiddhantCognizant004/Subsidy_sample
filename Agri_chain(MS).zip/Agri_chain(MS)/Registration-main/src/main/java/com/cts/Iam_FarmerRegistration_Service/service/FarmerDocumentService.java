package com.cts.Iam_FarmerRegistration_Service.service;

import com.cts.Iam_FarmerRegistration_Service.dao.FarmerDocumentRepo;
import com.cts.Iam_FarmerRegistration_Service.entity.FarmerDocument;
import com.cts.Iam_FarmerRegistration_Service.enums.VerificationStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FarmerDocumentService {

    @Autowired
    private FarmerDocumentRepo documentRepo;

    public FarmerDocument uploadDocument(FarmerDocument document) {
        return documentRepo.save(document);
    }

    public List<FarmerDocument> getDocumentsByFarmer(Long farmerId) {
        return documentRepo.findAll()
                .stream()
                .filter(doc -> doc.getFarmer() != null && doc.getFarmer().getFarmerId().equals(farmerId))
                .toList();
    }

    public FarmerDocument verifyDocument(Long documentId, VerificationStatus status) {
        FarmerDocument doc = documentRepo.findById(documentId).orElse(null);
        if (doc != null) {
            doc.setVerificationStatus(status);
            return documentRepo.save(doc);
        }
        return null;
    }
}