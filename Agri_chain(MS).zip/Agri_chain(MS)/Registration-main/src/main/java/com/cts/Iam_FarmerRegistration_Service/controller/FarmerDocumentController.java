package com.cts.Iam_FarmerRegistration_Service.controller;

import com.cts.Iam_FarmerRegistration_Service.entity.Farmer;
import com.cts.Iam_FarmerRegistration_Service.entity.FarmerDocument;
import com.cts.Iam_FarmerRegistration_Service.enums.VerificationStatus;
import com.cts.Iam_FarmerRegistration_Service.service.FarmerDocumentService;
import com.cts.Iam_FarmerRegistration_Service.service.FarmerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/documents")
public class FarmerDocumentController {

    @Autowired
    private FarmerDocumentService documentService;

    @Autowired
    private FarmerService farmerService;

    @PostMapping("/farmer/{farmerId}")
    public FarmerDocument uploadDocument(@PathVariable Long farmerId, @RequestBody FarmerDocument document) {
        Farmer farmer = farmerService.getFarmerById(farmerId);
        if (farmer != null) {
            document.setFarmer(farmer);
        }
        return documentService.uploadDocument(document);
    }

    @GetMapping("/farmer/{farmerId}")
    public List<FarmerDocument> getDocumentsByFarmer(@PathVariable Long farmerId) {
        return documentService.getDocumentsByFarmer(farmerId);
    }

    @PatchMapping("/{documentId}/verify")
    public FarmerDocument verifyDocument(@PathVariable Long documentId,
                                         @RequestParam("status") VerificationStatus status) {
        return documentService.verifyDocument(documentId, status);
    }
}