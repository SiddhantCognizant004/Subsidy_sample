package com.cts.Iam_FarmerRegistration_Service.entity;

import com.cts.Iam_FarmerRegistration_Service.enums.DocType;
import com.cts.Iam_FarmerRegistration_Service.enums.VerificationStatus;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "farmer_document")
public class FarmerDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    @JsonBackReference
    private Farmer farmer;

    @Enumerated(EnumType.STRING)
    private DocType docType;

    private String fileUri;
    private LocalDate uploadedDate;

    @Enumerated(EnumType.STRING)
    private VerificationStatus verificationStatus;

    @PrePersist
    protected void onCreate() {
        this.uploadedDate = LocalDate.now();
        this.verificationStatus = VerificationStatus.PENDING;
    }
}