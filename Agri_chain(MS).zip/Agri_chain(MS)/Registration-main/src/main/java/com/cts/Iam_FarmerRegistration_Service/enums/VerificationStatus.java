package com.cts.Iam_FarmerRegistration_Service.enums;

public enum VerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED
}
