package com.cts.Iam_FarmerRegistration_Service.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    DELETED,
    SUSPENDED
}
