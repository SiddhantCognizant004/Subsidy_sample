package com.cts.Iam_FarmerRegistration_Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class IamFarmerRegistrationServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(IamFarmerRegistrationServiceApplication.class, args);
		System.out.println("Worked - Service Started Successfully");
	}
}