package com.cts.Iam_FarmerRegistration_Service.service;

import com.cts.Iam_FarmerRegistration_Service.dao.UserRepo;
import com.cts.Iam_FarmerRegistration_Service.dao.FarmerRepo;
import com.cts.Iam_FarmerRegistration_Service.dto.request.LoginRequestDTO;
import com.cts.Iam_FarmerRegistration_Service.dto.request.UserRequestDTO;
import com.cts.Iam_FarmerRegistration_Service.dto.response.UserResponseDTO;
import com.cts.Iam_FarmerRegistration_Service.entity.Users;
import com.cts.Iam_FarmerRegistration_Service.entity.Farmer;
import com.cts.Iam_FarmerRegistration_Service.enums.UserRole;
import com.cts.Iam_FarmerRegistration_Service.enums.UserStatus;
import com.cts.Iam_FarmerRegistration_Service.enums.FarmerStatus;
import com.cts.Iam_FarmerRegistration_Service.exception.UserConflictException;
import com.cts.Iam_FarmerRegistration_Service.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private FarmerRepo farmerRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JWTService jwtService;

    /**
     * Registers a User and automatically creates a corresponding Farmer profile
     * if the role is FARMER. Uses @Transactional to ensure data consistency.
     */
    @Transactional
    public String registerUser(UserRequestDTO dto) {
        // 1. Check for duplicates
        userRepo.findByEmail(dto.getEmail()).ifPresent(u -> {
            throw new UserConflictException("Email already exists: " + dto.getEmail());
        });

        userRepo.findByPhone(dto.getPhone()).ifPresent(u -> {
            throw new UserConflictException("Phone already exists: " + dto.getPhone());
        });

        // 2. Build and Save the User (Auth Table)
        Users user = Users.builder()
                .email(dto.getEmail())
                .name(dto.getName())
                .phone(dto.getPhone())
                .password(passwordEncoder.encode(dto.getPassword()))
                .role(dto.getRole() != null ? dto.getRole() : UserRole.FARMER)
                .status(UserStatus.ACTIVE) // Defaulting to ACTIVE for testing; change if approval is needed
                .build();

        Users savedUser = userRepo.save(user);

        if (savedUser.getRole() == UserRole.FARMER) {
            Farmer farmer = new Farmer();
            farmer.setUsers(savedUser); // Links foreign key userId
            farmer.setName(savedUser.getName());
            farmer.setEmail(savedUser.getEmail());
            farmer.setContactInfo(savedUser.getPhone());
            farmer.setDob(dto.getDob());
            farmer.setGender(dto.getGender());
            farmer.setAddress(dto.getAddress());
            farmer.setLandDetails(dto.getLandDetails());

            farmer.setStatus(FarmerStatus.ACTIVE);

            farmerRepo.save(farmer);
        }

        return "User and Farmer profile registered successfully";
    }

    public String validateLogin(LoginRequestDTO dto) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getPassword())
        );

        if (!authentication.isAuthenticated()) {
            throw new UserConflictException("Invalid email or password");
        }

        Users user = userRepo.findByEmail(dto.getEmail())
                .orElseThrow(() -> new UserConflictException("User not found"));

        if (user.getStatus() != UserStatus.ACTIVE) {
            throw new UserConflictException("User account is inactive or deleted");
        }

        return jwtService.generateToken(dto.getEmail());
    }

    public UserResponseDTO fetchUserById(Long id) {
        Users user = userRepo.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id, HttpStatus.NOT_FOUND));

        return mapToResponse(user);
    }

    public UserResponseDTO mapToResponse(Users user) {
        return UserResponseDTO.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .role(user.getRole())
                .status(user.getStatus())
                .build();
    }

    public List<UserResponseDTO> getAllUsers() {
        return userRepo.findAll().stream().map(this::mapToResponse).toList();
    }

    @Transactional
    public String deactivateUser(Long userId) {
        Users user = userRepo.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found", HttpStatus.NOT_FOUND));
        user.setStatus(UserStatus.INACTIVE);
        userRepo.save(user);
        return "User deactivated successfully";
    }
}