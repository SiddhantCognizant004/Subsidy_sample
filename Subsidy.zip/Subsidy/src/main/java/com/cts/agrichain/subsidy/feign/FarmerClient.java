package com.cts.agrichain.subsidy.feign;

import com.cts.agrichain.subsidy.dto.FarmerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "FARMER-SERVICE")
public interface FarmerClient {

    @GetMapping("/farmers/{id}")
    FarmerDTO getFarmerById(@PathVariable("id") Integer id);
}