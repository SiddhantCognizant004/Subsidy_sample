package com.cts.agrichain.subsidy.service;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

@Service
public class SecurityServiceImpl implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String username) {
        // Temporary user loading for JWT validation
        // Later this can be connected to Auth/User Microservice
        return User.builder()
                .username(username)
                .password("")
                .roles("ADMIN")
                .build();
    }
}