package com.cts.agrichain.subsidy.client;

import jakarta.validation.Valid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "Farmer-Service")
public interface FarmerClient {
//    @PostMapping("/api/reports/generate")
//    public FarmerDto generateReport(@Valid @RequestBody FarmerDto farmerDto);
}
