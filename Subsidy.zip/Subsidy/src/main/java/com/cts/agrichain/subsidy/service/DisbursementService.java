package com.cts.agrichain.subsidy.service;

import com.cts.agrichain.subsidy.dao.DisbursementRepo;
import com.cts.agrichain.subsidy.dao.SubsidyProgramRepo;
import com.cts.agrichain.subsidy.dto.DisbursementDTO;
import com.cts.agrichain.subsidy.dto.FarmerDTO;
import com.cts.agrichain.subsidy.entity.Disbursement;
import com.cts.agrichain.subsidy.entity.SubsidyProgram;
import com.cts.agrichain.subsidy.enums.DisbursementStatus;
import com.cts.agrichain.subsidy.feign.FarmerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class DisbursementService {

    @Autowired
    private DisbursementRepo disbursementRepo;

    @Autowired
    private SubsidyProgramRepo subsidyProgramRepo;

    @Autowired
    private FarmerClient farmerClient;

    public Disbursement applyForSubsidy(DisbursementDTO dto) {

        // Validate Farmer from Farmer Microservice
        FarmerDTO farmer = farmerClient.getFarmerById(dto.getFarmerId());
        if (farmer == null) {
            throw new RuntimeException("Farmer not found with ID: " + dto.getFarmerId());
        }

        // Validate Subsidy Program
        SubsidyProgram program = subsidyProgramRepo.findById(dto.getProgramId())
                .orElseThrow(() -> new RuntimeException("Subsidy Program not found with ID: " + dto.getProgramId()));

        Disbursement disbursement = new Disbursement();
        disbursement.setFarmerId(dto.getFarmerId());
        disbursement.setSubsidyProgram(program);
        disbursement.setDisbursementAmount(dto.getDisbursementAmount());
        disbursement.setDisbursementDate(LocalDate.now());
        disbursement.setDisbursementStatus(DisbursementStatus.PENDING);

        return disbursementRepo.save(disbursement);
    }

    public Disbursement getById(int id) {
        return disbursementRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Disbursement not found with ID: " + id));
    }

    public List<Disbursement> getAll() {
        return disbursementRepo.findAll();
    }

    public Disbursement reviewDisbursement(int id, DisbursementStatus status) {
        Disbursement disbursement = disbursementRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Disbursement not found with ID: " + id));

        disbursement.setDisbursementStatus(status);
        return disbursementRepo.save(disbursement);
    }

    public List<Disbursement> getByFarmerId(int farmerId) {
        return disbursementRepo.findByFarmerId(farmerId);
    }

    public List<Disbursement> getByProgramId(int programId) {
        return disbursementRepo.findBySubsidyProgram_ProgramID(programId);
    }
}